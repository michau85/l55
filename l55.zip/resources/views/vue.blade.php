@extends('layouts.app') 
@section('content')
<div class="container">
    <h1>Laravel 5.5</h1>
    <ex></ex>
</div>
@endsection