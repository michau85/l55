<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class moj extends Controller
{
    public function l55()
    {
        return 'l55';
    }

    public function vue()
    {
        return view('vue');
    }
}
